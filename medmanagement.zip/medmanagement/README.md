### Student Management System 
Business Requirement:

Your task is to create a basic School Management System where students can register to course, and view the course assigned to them.


Notes: 
- Fork repo



[Project Details](medmanagement.pdf)